#ifndef ENDPOINT_HORIZONTAL_LAYOUT_IMPL_H
#define ENDPOINT_HORIZONTAL_LAYOUT_IMPL_H
#include <commproto/control/endpoint/HorizontalLayout.h>

namespace commproto
{
    namespace control
    {
        namespace endpoint
        {
            
        }
    }
}

#endif //HORIZONTAL_LAYOUT_IMPL_H
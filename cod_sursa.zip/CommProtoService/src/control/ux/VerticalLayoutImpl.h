#ifndef UX_VERTICAL_LAYOUT_IMPL_H
#define UX_VERTICAL_LAYOUT_IMPL_H
#include <commproto/control/ux/VericalLayout.h>

namespace commproto
{
	namespace control
	{
		namespace ux
		{
		}
	}
}

#endif //UX_VERTICAL_LAYOUT_IMPL_H
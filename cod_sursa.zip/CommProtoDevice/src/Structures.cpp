#include <commproto/authdevice/Structures.h>		

namespace commproto
{
	namespace authdevice
	{
		const ConnectionData ConnectionData::defaultData = { "CPEP::Thermostat","COMPROTO","192.168.1.10",9001 };
	}
}
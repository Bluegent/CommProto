#ifndef UX_HORIZONTAL_LAYOUT_IMPL_H
#define UX_HORIZONTAL_LAYOUT_IMPL_H
#include <commproto/control/ux/HorizontalLayout.h>

namespace commproto
{
    namespace control
    {
        namespace ux
        {
        }
    }
}

#endif //UX_HORIZONTAL_LAYOUT_IMPL_H
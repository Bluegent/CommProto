#include <commproto/variable/Variable.h>

namespace commproto
{
    namespace variable
    {
    }
}
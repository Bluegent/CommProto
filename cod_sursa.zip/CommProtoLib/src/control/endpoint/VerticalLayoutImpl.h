#ifndef ENDPOINT_VERTICAL_LAYOUT_IMPL_H
#define ENDPOINT_VERTICAL_LAYOUT_IMPL_H
#include <commproto/control/endpoint/VericalLayout.h>

namespace commproto
{
	namespace control
	{
		namespace endpoint
		{

		}
	}
}

#endif //ENDPOINT_VERTICAL_LAYOUT_IMPL_H
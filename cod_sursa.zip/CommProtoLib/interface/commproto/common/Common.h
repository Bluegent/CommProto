#ifndef COMMPROTO_COMMON_H
#define COMMPROTO_COMMON_H
#include <vector>
#include <stdint.h>

namespace commproto
{
	using Message = std::vector<char>;
}
#endif